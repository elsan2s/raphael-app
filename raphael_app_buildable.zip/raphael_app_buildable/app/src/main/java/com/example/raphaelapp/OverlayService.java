package com.example.raphaelapp;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager windowManager;
    private View overlayView;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_layout, null);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 16;
        params.y = 120;

        overlayView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;
            private long downTime;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        downTime = System.currentTimeMillis();
                        return false;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(overlayView, params);
                        return true;
                }
                return false;
            }
        });

        Button toggle = overlayView.findViewById(R.id.toggleButton);
        LinearLayout content = overlayView.findViewById(R.id.contentLayout);
        TextView response = overlayView.findViewById(R.id.responseView);

        toggle.setOnClickListener(v -> content.setVisibility(content.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
        overlayView.findViewById(R.id.btnDyingFast).setOnClickListener(v -> response.setText(
                "Defesa primeiro.\n\n" +
                "Dano mágico burst: Athena's Shield.\n" +
                "Dano mágico contínuo: Radiant Armor.\n" +
                "Dano físico de skill: Antique Cuirass.\n" +
                "Dano físico básico/crítico: Blade Armor."
        ));
        overlayView.findViewById(R.id.btnNoDamage).setOnClickListener(v -> response.setText(
                "Você precisa de dano ou penetração.\n\n" +
                "Atirador/assassino: dano + penetração.\n" +
                "Mago: Divine Glaive se inimigos têm defesa mágica.\n" +
                "Não force luta se estiver atrás em ouro."
        ));
        overlayView.findViewById(R.id.btnTooMuchSustain).setOnClickListener(v -> response.setText(
                "Anti-cura obrigatório.\n\n" +
                "Tank/roam/exp: Dominance Ice.\n" +
                "Mago: Necklace of Durance.\n" +
                "Dano físico: Sea Halberd.\n" +
                "Foca objetivo, não troca longa."
        ));
        overlayView.findViewById(R.id.btnClose).setOnClickListener(v -> stopSelf());

        windowManager.addView(overlayView, params);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (overlayView != null) windowManager.removeView(overlayView);
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
